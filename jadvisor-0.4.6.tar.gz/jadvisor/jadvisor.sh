cd bin
java jadvisor/advisorui/Advisor
cd ..